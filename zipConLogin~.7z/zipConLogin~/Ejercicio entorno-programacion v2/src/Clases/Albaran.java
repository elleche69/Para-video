
package Clases;



public class Albaran {
    
    private int num_albaran;
    
    private String origen;
    
    private String destino;
    
    private String material;
            
    private float bruto;
        
    private float neto;
    
    private String contenedor;

    public Albaran(int num_albaran, String origen, String destino, String material, float bruto, float neto, String contenedor) {
        this.num_albaran = num_albaran;
        this.origen = origen;
        this.destino = destino;
        this.material = material;
        this.bruto = bruto;
        this.neto = neto;
        this.contenedor = contenedor;
    }

    public int getNum_albaran() {
        return num_albaran;
    }

    public void setNum_albaran(int num_albaran) {
        this.num_albaran = num_albaran;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public float getBruto() {
        return bruto;
    }

    public void setBruto(float bruto) {
        this.bruto = bruto;
    }

    public float getNeto() {
        return neto;
    }

    public void setNeto(float neto) {
        this.neto = neto;
    }

    public String getContenedor() {
        return contenedor;
    }

    public void setContenedor(String contenedor) {
        this.contenedor = contenedor;
    }
    
    
    
    
    
    
}
