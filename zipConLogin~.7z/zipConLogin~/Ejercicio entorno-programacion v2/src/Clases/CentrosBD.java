


package Clases;

import java.util.ArrayList;
import java.sql.*;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;



public class CentrosBD extends GenericBD{
    
    private static ArrayList<Centros> centros;
    
    public static ArrayList<Centros> Introducir_datos_en_combo(){
    
       try{
           Centros centro;
           
           GenerarConexion();          
           centros = new ArrayList();
           String lista = "Select * from CENTROSBD";                             
           PreparedStatement ps = GenericBD.getCon().prepareStatement(lista);
           ResultSet resultado = ps.executeQuery();
           
           
           
           while(resultado.next()){           
               centro = new Centros(Integer.parseInt(resultado.getString("ID")),resultado.getString("NOMBRE"), resultado.getString("CALLE"), resultado.getInt("NUMERO"), resultado.getString("CP"), resultado.getString("CIUDAD"), resultado.getString("PROVINCIA"), resultado.getString("TELEFONO"));
               centros.add(centro);
               System.out.print(centro.getId());
           }
           
           
           return centros;
           
        }   
           
        catch(Exception e){return null;}
        
        finally{
         
           cerrarConexion();
       
       }}    
        
       
    
       
        
            
    public static void AñadirCentro(Centros centro){
       
       try{
       
           GenerarConexion();
           
           String insert = "Insert into CentrosBD values(?,?,?,?,?,?,?,?)";
           PreparedStatement statement = GenericBD.getCon().prepareStatement(insert);
           statement.setInt(1, centro.getId());
           statement.setString(2, centro.getNombre());
           statement.setString(3, centro.getCalle());
           statement.setInt(4, centro.getNumero());
           statement.setString(5, centro.getCodigo());
           statement.setString(6, centro.getCiudad());
           statement.setString(7, centro.getProvincia());
           statement.setString(8, centro.getTelefono());
           
           statement.executeUpdate();
                      
       }
       catch(Exception e){}
    }   
       
       
   public static void EliminarCentro(int id){
   
       try{
       
           GenerarConexion();
           String delete = "delete from CentrosBD where ID = ?";
           PreparedStatement statement = GenericBD.getCon().prepareStatement(delete);
           statement.setInt(1, id);
           statement.executeUpdate();
       }
       catch(Exception e){}
    }   
       
       
    public static void ModificarCentro(Centros centro){
    
        try{
        
            GenerarConexion();
            String update = "Update CENTROSBD set"
                                          + " nombre = ?,"
                                          + " calle = ?,"
                                          + " numero = ?,"
                                          + " cp = ?,"
                                          + " ciudad = ?,"
                                          + " provincia = ?,"
                                          + " telefono = ?"
                                          + " Where id = ?";
            
            PreparedStatement updateSQL = GenericBD.getCon().prepareStatement(update);            
            updateSQL.setString(1, centro.getNombre());
            updateSQL.setString(2, centro.getCalle());
            updateSQL.setInt(3, centro.getNumero());
            updateSQL.setString(4, centro.getCodigo());
            updateSQL.setString(5, centro.getCiudad());
            updateSQL.setString(6, centro.getProvincia());
            updateSQL.setString(7, centro.getTelefono());
            updateSQL.setInt(8, centro.getId());
            
            updateSQL.executeUpdate();
            
            
        
        
        }
        catch(Exception e){}
    } 
        
    
    
    
    
    
    
    
    
    public static ArrayList<Trabajadores> VisualizarTrabajadoresCentro(int id){
        GenerarConexion();
        ArrayList<Trabajadores> listado = new ArrayList();
        ArrayList<String> tipo = new ArrayList();
        try{
                     
            CallableStatement cod = GenericBD.getCon().prepareCall("{call procedimiento (?,?)}");                     
            cod.setInt(1, id);             
            cod.registerOutParameter(2, OracleTypes.CURSOR);            
            cod.execute();            
            ResultSet resultados = (ResultSet)cod.getObject(2);                        
            while (resultados.next()){     
                
                Trabajadores mt = new Trabajadores(resultados.getString(1),resultados.getString(2), resultados.getString(3), resultados.getString(4), resultados.getString(5), resultados.getString(6), Integer.parseInt(resultados.getString(7)), resultados.getString(8), resultados.getString(9), resultados.getString(10), Integer.parseInt(resultados.getString(12)), resultados.getString(11));
                listado.add(mt);
                tipo.add(resultados.getString(14));
                
            }
            
            ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.CargaADemanda(id, listado);
    
    
        }
        catch(Exception e){System.out.print("Fail");}
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.RecogerTipo(tipo);
        return listado;
    }    
    
    
    
      
       
   
   
   
   
   
   
   
       
       
    
    
    
     
       
       
       
      
       
       
       
       
       
       
       
       
    
        
    
    
    
    
    
    
    
    
    
    
    
}
