
package Clases;
import java.sql.Connection;
import java.sql.DriverManager;

public abstract class GenericBD {
    
    protected static Connection con;

    
    public static boolean GenerarConexion(){
        
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            
            String login="daw09";
            String password= "daw09";
            String url = "jdbc:oracle:thin:@SrvOracle:1521:orcl";
            con = DriverManager.getConnection(url,login,password);
            return true;
        
        }
        catch(Exception e){
            return false;
        }
    }    
    
    
    public static boolean cerrarConexion(){
        try{
            con.close();
            return true;            
        }
        catch(Exception e){return false;}
    }        
        
    
    
      public static Connection getCon() {
        return con;
    }

    public static void setCon(Connection con) {
        GenericBD.con = con;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
