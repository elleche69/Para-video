
package Clases;

import static Clases.GenericBD.GenerarConexion;
import static Clases.GenericBD.cerrarConexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;



public class PartesBD {
    
   private static ArrayList<Partes> partes;
           
    public static ArrayList<Partes> BuscarPartesDelTrabajador(String dni){
    
               
        try{
            partes  = new ArrayList();
            Partes parte;
            GenerarConexion();
            String lista = "Select * from partestrabajobd where Dni_Logis = ? and Estado_Parte = ? order by num_parte"; 
            PreparedStatement ps = GenericBD.getCon().prepareStatement(lista); 
            ps.setString(1, dni);
            ps.setString(2, "Abierto");
            ResultSet resultado = ps.executeQuery();
            System.out.print("E");
            while (resultado.next()){
            
                parte = new Partes(resultado.getInt(1), resultado.getInt(2), resultado.getInt(3), resultado.getInt(4), resultado.getInt(5), resultado.getInt(6), resultado.getInt(7), resultado.getDate(11).toString(), resultado.getString(12), resultado.getString(8));
                System.out.print(parte.getId());
                partes.add(parte);
            }
        }    
        catch(Exception e){System.out.print("A");}
        cerrarConexion();
        return partes;
    }   
        
        
    public static boolean ComprobarFechaSiEstaDuplicado(String fecha){
        
        boolean b = false;
        try{
            
            GenerarConexion();        
            String busqueda = "Select * from partestrabajobd where fecha_parte = ?";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(busqueda);
            preparado.setString(1, fecha);
          
            ResultSet resultado = preparado.executeQuery();               
            if(resultado.next()){b = true;} 
            else{b = false;}
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "Q");}    
        cerrarConexion();    
        return b;     
    }         
     
    
    
    public static int GenerarId(){
    
        int id = 1;
        
        try{
            GenerarConexion(); 
            String busqueda = "select max(num_parte) from partestrabajobd";
            PreparedStatement preparado = GenericBD.getCon().prepareStatement(busqueda);
            ResultSet resultado = preparado.executeQuery(); 
            if(resultado.next()){
                id = resultado.getInt(1);
            }
            
        }
        catch(Exception e){}
        cerrarConexion();
        return id;
    }
            
    public static void GenerarParteNuevo(Partes parte){
    
        try{
          
            GenerarConexion();
            String insertar = "Insert into Partestrabajobd(NUM_PARTE, DNI_LOGIS, FECHA_PARTE, ESTADO_PARTE) Values(?,?,?,?)";
            
            PreparedStatement preparado_industrial = GenericBD.getCon().prepareStatement(insertar);
            preparado_industrial.setInt(1, parte.getId());
            preparado_industrial.setString(2, parte.getTrabajador_logis().getDni());
            preparado_industrial.setString(3, parte.getFecha());
            preparado_industrial.setString(4, parte.getEstado());
            preparado_industrial.executeUpdate();
        
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "L");} 
        cerrarConexion();
    
    
        
    
    }        
        
        
    public static void UpdateElParte(Partes parte){
        
        
        
        try{
        
            GenerarConexion();
            String update = "Update partestrabajobd set KM_INICIO = ?, KM_FINAL = ?, GASTOS_GASOIL = ?, GASTOS_PEAJES = ?, GASTOS_DIETAS = ?, OTROS_GASTOS = ? where num_parte = ?";
            PreparedStatement preparado_industrial = GenericBD.getCon().prepareStatement(update);
            preparado_industrial.setInt(1, parte.getKm_inicio());
            preparado_industrial.setInt(2, parte.getKm_final());
            preparado_industrial.setInt(3, parte.getGastos_gasoil());
            preparado_industrial.setInt(4, parte.getGastos_peaje());
            preparado_industrial.setInt(5, parte.getGastos_dietas());
            preparado_industrial.setInt(6, parte.getOtros_gastos());
            preparado_industrial.setInt(7, parte.getId());
            preparado_industrial.executeUpdate();
            
            
        }
        catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null, "P");}
        cerrarConexion();
    }
    
    
    public static void CerrarPorTerceraVez(Partes parte){
    
        try{
            GenerarConexion();
            String update = "Update partestrabajobd set KM_INICIO = ?, KM_FINAL = ?, GASTOS_GASOIL = ?, GASTOS_PEAJES = ?, GASTOS_DIETAS = ?, OTROS_GASTOS = ?, ESTADO_PARTE = ?, MATRICULA = ? where num_parte = ?";
            PreparedStatement preparado_industrial = GenericBD.getCon().prepareStatement(update);
            preparado_industrial.setInt(1, parte.getKm_inicio());
            preparado_industrial.setInt(2, parte.getKm_final());
            preparado_industrial.setInt(3, parte.getGastos_gasoil());
            preparado_industrial.setInt(4, parte.getGastos_peaje());
            preparado_industrial.setInt(5, parte.getGastos_dietas());
            preparado_industrial.setInt(6, parte.getOtros_gastos());
            preparado_industrial.setString(7, "Cerrado");
            preparado_industrial.setString(8, parte.getVehiculo().getMatricula());
            preparado_industrial.setInt(9, parte.getId());
            preparado_industrial.executeUpdate();
        
        
        
        
        
        }
        catch(Exception e){}
        cerrarConexion();
        
    
    
    
    
    
    
    
    }
    
    
        
    
    
        
   
    
    
    
    
    
}
