/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author itziar
 */
public class TrabajadoresLogistica extends Trabajadores{

    public TrabajadoresLogistica(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, int salario, String fecha_nac, Centros centro) {
        super(dni, nombre, apellido1, apellido2, calle, portal, piso, mano, telefono1, telefono2, salario, fecha_nac, centro);
    }

    public TrabajadoresLogistica(String dni, String nombre, String apellido1, String apellido2) {
        super(dni, nombre, apellido1, apellido2);
    }

    public TrabajadoresLogistica(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, int salario, String fecha_nac, String tipo) {
        super(dni, nombre, apellido1, apellido2, calle, portal, piso, mano, telefono1, telefono2, salario, fecha_nac, tipo);
    }

    public TrabajadoresLogistica(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, int salario, String fecha_nac) {
        super(dni, nombre, apellido1, apellido2, calle, portal, piso, mano, telefono1, telefono2, salario, fecha_nac);
    }

    public TrabajadoresLogistica(String dni, String nombre, String apellido1, String apellido2, String calle, String portal, int piso, String mano, String telefono1, String telefono2, int salario, String fecha_nac, Centros centro, String tipo) {
        super(dni, nombre, apellido1, apellido2, calle, portal, piso, mano, telefono1, telefono2, salario, fecha_nac, centro, tipo);
    }
    

    
    
    
    
    
}
