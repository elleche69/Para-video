
package Clases;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;





public class VehiculosBD {
    
    
    private static ArrayList<Vehiculo> listado;
    
    public static ArrayList<Vehiculo> DevuelveLaLista(){
    
        
        listado = new ArrayList();
        
        try{
            GenericBD.GenerarConexion();
            String lista = "Select * from Vehiculo";            
            PreparedStatement ps = GenericBD.getCon().prepareStatement(lista);
            ResultSet ptbd = ps.executeQuery();
        
            while(ptbd.next()){            
                Vehiculo ferrari = new Vehiculo(ptbd.getString(1), ptbd.getString(2), ptbd.getString(3));
                listado.add(ferrari);            
            }
        
        
        }
        catch(Exception e){}
        
        GenericBD.cerrarConexion();
        
       
        return listado;
    }

    
    public static Vehiculo ConseguirVehiculo(String matricula){
    
        Vehiculo b = null;
    
        int n = 0;
        
        while (n < listado.size()){
        
            if (matricula.equalsIgnoreCase(listado.get(0).getMatricula())){
                b = listado.get(n);
                n = listado.size() + 1;
            }    
            else{n = n + 1;}
        }    
        return b;    
    }            
            
            
        
        
        
    
     public static ArrayList<Vehiculo> getListado() {
        return listado;
    }

    public static void setListado(ArrayList<Vehiculo> listado) {
        VehiculosBD.listado = listado;
    }
    
    
        
    
    
    
    
    
    
    
    
    
   
    
    
    
       
    
    
     
    
    
    
    
    
    
    
    
    
    
    
    
}
