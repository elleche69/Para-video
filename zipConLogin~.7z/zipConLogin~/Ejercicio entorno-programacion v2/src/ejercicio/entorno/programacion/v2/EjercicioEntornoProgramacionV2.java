




package ejercicio.entorno.programacion.v2;
import Ventanas.*;
import Clases.*;
import Excepciones.*;
import java.util.ArrayList;
import java.util.Date;





public class EjercicioEntornoProgramacionV2 {
    private static LoginTrabajador login;
    private static VentanaLineas ventana_lineas;
    private static VentanaPartes ventana_partes;
    private static VentanaInicio ventana_inicio;
    private static MenuCentros menu_centros;
    private static MenuTrabajadores menu_trabajadores;
    private static CRUDCentros crud_centros;
    private static CRUDTrabajadores crud_trabajadores;
    private static ArrayList<Centros> centros; 
    private static ArrayList<Partes> partes;
    private static int centro_index_seleccionado; 
    private static Trabajadores trabajador; 
    private static Centros centro; 
    private static int opcion; 
    private static VisualizarTrabPorCentros visualizar;
    private static Login log;
    private static String dnit;
    private static String tipo = null;
    private static TrabajadoresLogistica logistica = null;
    private static TrabajadoresAdministracion administracion = null;
    
    
    public static void main(String[] args) {
        //ventana_lineas = new VentanaLineas();
        //ventana_lineas.setVisible(true);
        log = new Login(null, true);
        log.setVisible(true);
        
        
        
    }
    
    
  
    
    
//METODOS GENERAR VENTANAS    
    
    
    public static void EleccionGenerarVentanas(int b, int n){
    
        switch (n){
        
            case 1:               
                GenerarVentanaPrincipal(b);
                break;                       
            case 2:
                GenerarMenuCentros(b);
                break;                            
            case 3:                             
                GenerarMenuTrabajadores(b);  
                break;            
            case 4:  
                GenerarCrudCentros();
                break;                
            case 5: 
                GenerarCrudTrabajadores();
                break;
            case 6: 
                GenerarTabla();
                break;
            case 7:
                GenerarVentanaParte(b);
                break;
            case 8:
                GenerarVentanaLineasParte();
                break;
                
        }        
    }            
               
                
    public static void GenerarVentanaPrincipal(int b){          
        switch (b){
            case 1:
                menu_centros.dispose();
                break;
            case 2: 
                menu_trabajadores.dispose();
                break;}            
        ventana_inicio = new VentanaInicio();
        ventana_inicio.setVisible(true);
    }     
        
        
       
    public static void GenerarMenuCentros(int b){    
        if(b == 1){
            crud_centros.dispose();}
        else{
            if(b ==2){visualizar.dispose();}
            else{ ventana_inicio.dispose();}
        }  
        
        
        
        menu_centros = new MenuCentros();
        menu_centros.setVisible(true);
    }    
    
    
        
    public static void GenerarMenuTrabajadores(int b){    
        if (b == 1){
            crud_trabajadores.dispose();}        
        else{ventana_inicio.dispose();}                
        menu_trabajadores = new MenuTrabajadores();
        menu_trabajadores.setVisible(true);
    
    }
    
    
    public static void GenerarCrudCentros(){
        menu_centros.dispose();        
        crud_centros = new CRUDCentros();
        crud_centros.setVisible(true);
    }
    
    public static void GenerarCrudTrabajadores(){
        menu_trabajadores.dispose();
        crud_trabajadores = new CRUDTrabajadores();
        crud_trabajadores.setVisible(true);
    }
    
    
    public static void GenerarTabla(){
    
        menu_centros.dispose();
        visualizar = new VisualizarTrabPorCentros();
        visualizar.setVisible(true);
    
    
    }
    
    public static void GenerarVentanaParte(int b){        
        if (b == 1){ventana_lineas.dispose();}
        ventana_partes = new VentanaPartes();
        ventana_partes.setVisible(true);
    }
    
    public static void GenerarVentanaLineasParte(){
        ventana_partes.dispose();
        ventana_lineas = new VentanaLineas();
        ventana_lineas.setVisible(true);
    }    
    
    
    
    
    
    
//FINAL METODOS GENERAR VENTANAS    
    
    
//METODOS RELATIVOS A MENUS    
    public static void ConseguirIdsDeLaBase(int g){                      
        centros = CentrosBD.Introducir_datos_en_combo();
        
        if(g == 1){ menu_trabajadores.RecuperarDatosIds(centros);}
        else{menu_centros.RecuperarDatosDeLaBase(centros);} 
    }        
            
                        
    
    public static void ConseguirCentroSeleccionado(int id){
    
        centro_index_seleccionado = id;        
    }
    
    
    public static void ConseguirOpcion(int n){  
        opcion = n;
        crud_trabajadores.PasarIndexOpcion(n);    
    }
    
    
//FIN DE LOS METODOS DE ESTE TIPO   
    
    
  
//LLAMADA A METODOS "CRUD" TRABAJADORES
       
    public static void Modificar(ArrayList<String> data, String tipo_modif){
    
        int cx = 0;        
        while(centros.get(cx).getId() != centro_index_seleccionado){        
            cx = cx + 1;        
        }        
        centro = centros.get(cx);        
        trabajador = new Trabajadores(data.get(0),data.get(1),data.get(2),data.get(3),data.get(4), data.get(5),Integer.parseInt(data.get(6)), data.get(7), data.get(8), data.get(9), Integer.parseInt(data.get(10)),data.get(11), centro); 
        System.out.print(tipo_modif);
        Clases.TrabajadoresBD.Modificar_datos(trabajador, tipo_modif);    
    }  
           
    
    public static void Añadir(ArrayList<String> data, String tipe){
    
        if(Clases.TrabajadoresBD.Comprobar(data.get(0)) == true){
           
            int cx = 0;        
            while(centros.get(cx).getId() != centro_index_seleccionado){        
            cx = cx + 1;}  
            centro = centros.get(cx);   
            trabajador = new Trabajadores(data.get(0),data.get(1),data.get(2),data.get(3),data.get(4), data.get(5),Integer.parseInt(data.get(6)), data.get(7), data.get(8), data.get(9), Integer.parseInt(data.get(10)),data.get(11), centro);        
            
            Clases.TrabajadoresBD.Añadir_Nuevo(trabajador, tipe);           
       }
    }
        
           
    public static void Borrar(String dna){
    
        Clases.TrabajadoresBD.Borrar_Datos(dna);
   } 
    
//FIN DE METODOS CRUD TRABAJADORES    
    
    
    
    
   public static void Validar_Dato_Introducido(String dna){
   
       Trabajadores ttrabajador = TrabajadoresBD.Validar_Trabajadores(dna, centro_index_seleccionado);
   
         if(ttrabajador != null && opcion == 1){
           
           crud_trabajadores.Habilitar_campos(true);
           crud_trabajadores.Enseñar_Datos(ttrabajador, tipo);
           crud_trabajadores.getTimer().stop();
        }   
           
        else{
       
           if(trabajador != null && opcion != 1){
           
               crud_trabajadores.Habilitar_campos(false);
               crud_trabajadores.Enseñar_Datos(ttrabajador, tipo);
               crud_trabajadores.getTimer().stop();
           }    
               
           else{           
               javax.swing.JOptionPane.showMessageDialog(null, "Trabajador no encontrado");
            }
        }      
   
   
   
   }
    
    public static void RecogerTipo(String tipoTrabajador){
    
        tipo = tipoTrabajador;
        
    
    }
    
     
    
    
    
    
    
//METODOS RELATIVOS A LOS CENTROS
   
   public static void RecojerOpcionEscogida(int h){      
       opcion = h;
       if (opcion != 1 && opcion != 4){
           crud_centros.RecogerCentro(centros.get(menu_centros.PasarIndex() - 1), opcion);}
       else{
       
           if(opcion != 4){crud_centros.RecogerCentro(null, opcion);}
           
           else{visualizar.EnseñarDatos(CentrosBD.VisualizarTrabajadoresCentro(menu_centros.PasarIndex()));}
        }       
    }           
    
   public static void RecogerTipo(ArrayList<String> todo_tipo){
   
       visualizar.EnseñarTipo(todo_tipo);
        
   }
       
    public static void CargaADemanda(int id, ArrayList<Trabajadores> trab){
    
       int n = 0;
        
        while (n < centros.size() && centros.get(n).getId() != id){
        
            n = n + 1;
        }         
        centros.get(n).setTrabajadores(trab);
    }   
    
    
       
       
            
        
           
    public static boolean ComprobarIdCentroNuevo(int id_nuevo){
    
        boolean b = false;
    
        int n = 0;
        
        while(n < centros.size()){        
            if (id_nuevo == centros.get(n).getId()){
                n = centros.size();
                b = true;}
            else{n = n + 1;}
        }       
        return b;    
    }        
        
    public static void FinalizarAccion(int eleccion, ArrayList<String> data){
        if (eleccion != 3){
            Centros centrox = new Centros(Integer.parseInt(data.get(0)), data.get(1), data.get(2), Integer.parseInt(data.get(3)), data.get(4), data.get(5), data.get(6), data.get(7));
            if(eleccion == 1){
                CentrosBD.AñadirCentro(centrox);
            }
            else{CentrosBD.ModificarCentro(centrox);}        
        }
        else{CentrosBD.EliminarCentro(Integer.parseInt(data.get(0)));}
    
    }
    
        
           
           
    
    
    
    
    
    //Metodos relativos al login
    
    
    
    
    public static void LograrTipoLogin(TrabajadoresLogistica t1, TrabajadoresAdministracion t2){    
        administracion = t2;
        logistica = t1;
    }
    
    
    
    public static void Entrada(String user, String contraseña){
    
        BuscarDNILogin(Clases.LoginTrabajadorBD.BuscarLoginSiEsCorrecto(user, contraseña));
        
    
    
    
    
    }
    
    
    public static void BuscarDNILogin(String dni){
        dnit = dni;
        Clases.TrabajadoresBD.BuscarLogin(dnit);
    
        if (administracion == null && logistica != null){
            
            log.dispose();
            
            partes = Clases.PartesBD.BuscarPartesDelTrabajador(dnit);
            EleccionGenerarVentanas(0,7);
            AñadirDatosPartes();
            
                      
        }
        else{   
           if(logistica == null && administracion != null){
                log.dispose();
                EleccionGenerarVentanas(0,1);
           }
           else{javax.swing.JOptionPane.showMessageDialog(null, "Jackeador cavron te vamos a partir las piernas");} 
        }       
    }            
            
        
    
        
        
        
    //Metodos relativos al las lineas y a los partes

    public static void Recuperar_Datos_Lineas(ArrayList<String> data){
    
            
    
    
    
    }
        
    
    
    public static void CogerListaFerrari(){
    
        ventana_partes.LlenarForocoches(Clases.VehiculosBD.DevuelveLaLista());
    }
    
    
    
    public static void GenerarParte(String fecha){
        
        Partes parte;
        
        parte = new Partes(PartesBD.GenerarId() + 1, fecha, "Abierto", logistica);
        
        if (PartesBD.ComprobarFechaSiEstaDuplicado(fecha) == false){
            PartesBD.GenerarParteNuevo(parte);
            ventana_partes.AñadirParteNuevo(parte);
            
        }    
        else{javax.swing.JOptionPane.showMessageDialog(ventana_lineas, "Parte ya generado en la misma fecha");}
    }    
        
        
        
    public static void AñadirDatosPartes(){
        ventana_partes.LlenarComboYTabla(partes);
    }    
    
    
    
    
    
    public static void EditarPartes(){    
        ArrayList<Integer> data = ventana_partes.RecojerDatosDeLaTabla();
        Partes parte = new Partes(data.get(6), data.get(0),  data.get(1),  data.get(2),  data.get(3),  data.get(4),  data.get(5), null, logistica);
        PartesBD.UpdateElParte(parte);
    }
    
    
    public static void CerrarPartes(ArrayList<Integer> data, String matricula){
    
        Partes parte = new Partes(data.get(6), data.get(0),  data.get(1),  data.get(2),  data.get(3),  data.get(4),  data.get(5), null, logistica, VehiculosBD.ConseguirVehiculo(matricula));
        PartesBD.CerrarPorTerceraVez(parte);
    }
    
    
    
    
    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static String getDnit() {
        return dnit;
    }

    public static void setDnit(String dnit) {
        EjercicioEntornoProgramacionV2.dnit = dnit;
    }

















} 
    
            
    
    
    
    
      
    
   
   
   
   
   
    
    
    
    

